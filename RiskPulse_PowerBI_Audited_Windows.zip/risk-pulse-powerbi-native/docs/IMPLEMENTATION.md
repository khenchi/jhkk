# Implementation notes

## Data ingestion
Each fact is loaded once to the shared semantic model. All five report pages reference the same model. Replace CSV M queries with validated Oracle source views later; preserve the canonical columns and their units. Use incremental refresh when date-partitioning and query folding are supported.

## Decision-driven target
1. Executive exception cards and severity badges, 2. desk/position P&L attribution, 3. anomaly severity against calibrated baselines, 4. rule-based suggested investigations, 5. optional governed incident workflow.

## Next native PBIR work
Implement slicers, drillthrough page filters, field parameters, bookmarks, navigation, per-desk module applicability and an alert-priority table. Validate all visuals using Desktop. Do not infer root causes from simple correlation.
