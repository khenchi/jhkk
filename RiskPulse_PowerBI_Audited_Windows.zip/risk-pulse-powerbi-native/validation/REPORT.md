# RiskPulse validation report — 2026-10-12

## Passed static checks

- 91 automated checks passed using `python validation/validate.py`: source CSV existence, declared columns versus CSV headers, shared loader references for 13 tables, DAX column dependencies, relationship endpoints, five report pages and 25 visuals, JSON syntax, inline parameter declaration.
- All 13 original CSV files retained unchanged (verified by SHA-256 against original ZIP during packaging).
- All 15 original measures, 16 relationships and 25 original visual JSON files retained; no business feature intentionally removed.
- All 12 synthetic book identifiers referenced by facts are valid; no orphan `book_id` in the 7 fact CSV files.
- No `/mnt/data` path remains in the project definitions.

## Fixes and root causes

1. UnsupportedObjectType: `meta [...]` was a separate TMDL line. M parameter metadata is now inline with `expression DataFolder = "..." meta [...]` per Microsoft TMDL documentation.
2. Non-portable source path: original Linux path replaced with a safe, intentionally invalid placeholder. Windows setup calculates absolute `data` folder path and rewrites only DataFolder.
3. Duplicated Power Query CSV parsing: replaced with shared `fxLoadCsv` that enforces expected headers and types, UTF-8, comma delimiter and quoted fields. Import tables still load each original CSV once.
4. Date and date-like dimension columns incorrectly defaulted to SUM: set summarizeBy to none, without changing values or business measures.

## NOT verified / requires Windows Power BI Desktop

- Native TMDL parser acceptance (no TOM/TMDL compiler available in build environment).
- Power Query M evaluation, Windows script execution (PowerShell not available here), Desktop CSV credential/privacy prompts, data refresh.
- PBIR visual schema rendering and interactive page navigation; JSON parsing alone is not equivalent to rendering.
- DAX engine execution and financial results reconciliation with source Excel reports.
- `.pbix` Save As and `.pbit` Export: both must be performed in Power BI Desktop. Neither file is present or represented as generated.

## Acceptance test in Desktop

1. Run `scripts/Initialize-RiskPulse.ps1`; rerun and verify it reports 'Already configured'.
2. Open `RiskPulse.pbip`; ensure no UnsupportedObjectType or TMDL errors.
3. Refresh; confirm 13 source tables load, no Power Query errors, 12 books and 5 pages visible.
4. Check Executive, Desk, Investigation, Decision, Customize pages; verify measures and visuals.
5. Save As `RiskPulse.pbix` and export `RiskPulse.pbit`; reopen both and validate refresh.
