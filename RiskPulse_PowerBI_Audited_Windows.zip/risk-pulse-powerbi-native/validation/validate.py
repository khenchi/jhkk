from pathlib import Path
import csv,json,re,sys,collections
root=Path(__file__).resolve().parents[1];definition=root/'RiskPulse.SemanticModel/definition';tables={}
errors=[];checks=[]
def check(cond,msg):
 checks.append((bool(cond),msg))
 if not cond:errors.append(msg)
for f in root.rglob('*.json'):
 try:json.loads(f.read_text(encoding='utf-8'))
 except Exception as e:errors.append(f'JSON {f}: {e}')
expr=(definition/'expressions.tmdl').read_text()
check(bool(re.search(r'^expression DataFolder = \".*?\" meta \[IsParameterQuery=true',expr,re.M)),'DataFolder M metadata inline')
check('expression fxLoadCsv =' in expr,'shared CSV loader defined')
for f in (definition/'tables').glob('*.tmdl'):
 s=f.read_text(); name=f.stem;cols=re.findall(r'^\tcolumn ([^\n]+)',s,re.M);tables[name]=set(cols)
 if name=='_Measures':continue
 check(f'fxLoadCsv("{name}.csv"' in s,f'{name} uses shared loader')
 path=root/'data'/f'{name}.csv'
 check(path.is_file(),f'{name} source CSV exists')
 if path.is_file():
  with path.open(encoding='utf-8-sig',newline='') as stream: hdr=next(csv.reader(stream))
  check(set(cols)==set(hdr),f'{name} CSV schema matches TMDL columns')
for f in (definition/'tables').glob('*.tmdl'):
 s=f.read_text()
 for t,c in re.findall(r'(?<![A-Za-z0-9_])([A-Za-z_][A-Za-z0-9_]*)\[([^]]+)\]',s):
  if t in tables:check(c in tables[t],f'{f.stem}: DAX ref {t}[{c}] exists')
rels=(definition/'relationships.tmdl').read_text()
for t,c in re.findall(r'(?:fromColumn|toColumn): ([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)',rels):check(t in tables and c in tables[t],f'relationship {t}.{c} exists')
measure=(definition/'tables/_Measures.tmdl').read_text();names=set(re.findall(r'^\tmeasure (?:\'([^\']+)\'|([^ =]+)) =',measure,re.M))
known={a or b for a,b in names}
for ref in re.findall(r'(?<![A-Za-z0-9_])\[([^]]+)\]',measure):
 if ref not in known and not re.search(r'\b\w+\['+re.escape(ref)+r'\]',measure):errors.append(f'Unknown measure: {ref}')
for f in (root/'RiskPulse.Report/definition').rglob('*.json'):
 try:json.loads(f.read_text())
 except Exception as e:errors.append(str(e))
check(len(list((root/'RiskPulse.Report/definition/pages').glob('*/page.json')))==5,'all 5 report pages retained')
check(len(list((root/'RiskPulse.Report/definition/pages').rglob('visual.json')))==25,'all 25 visuals retained')
print(f'Checks: {len(checks)}; failed: {len(errors)}')
for e in errors:print('FAIL:',e)
if errors:sys.exit(1)
print('PASS: static schema, references, JSON, layout count (not native TMDL parser or Desktop runtime)')
