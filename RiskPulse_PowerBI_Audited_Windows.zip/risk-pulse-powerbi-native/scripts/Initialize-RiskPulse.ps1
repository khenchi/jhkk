param([switch]$Open, [switch]$Force)
$ErrorActionPreference = 'Stop'
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$data = Join-Path $root 'data'
$expr = Join-Path $root 'RiskPulse.SemanticModel\definition\expressions.tmdl'
if (!(Test-Path -LiteralPath $expr -PathType Leaf)) { throw "Missing expressions.tmdl: $expr" }
$expected = @('dim_book','dim_component','dim_date','dim_position','dim_scenario','dim_underlying','fact_data_quality','fact_incident','fact_limit','fact_pnl','fact_sensitivity','fact_stress','fact_var')
foreach ($name in $expected) { if (!(Test-Path -LiteralPath (Join-Path $data "$name.csv") -PathType Leaf)) { throw "Missing CSV: $name.csv" } }
# M uses a Windows path; escape embedded double quotes for M string literals
$normalized = $data.TrimEnd('\','/') + '\'
if ($normalized.Contains('"')) { throw 'Unsupported quote character in data path.' }
$raw = [System.IO.File]::ReadAllText($expr)
$pattern = '(?m)^expression DataFolder = "(?:[^"]|"")*" meta \[IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true\]$'
if (-not [regex]::IsMatch($raw,$pattern)) { throw 'DataFolder declaration missing or modified; refusing to rewrite.' }
$replacement = 'expression DataFolder = "' + $normalized + '" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
$updated = [regex]::Replace($raw,$pattern,[System.Text.RegularExpressions.MatchEvaluator]{param($m) $replacement},1)
if ($updated -ne $raw) {
    $backup = "$expr.bak"
    if (!(Test-Path -LiteralPath $backup)) { [System.IO.File]::Copy($expr,$backup) }
    [System.IO.File]::WriteAllText($expr,$updated,[System.Text.UTF8Encoding]::new($false))
    Write-Host "Updated DataFolder: $normalized"
} else { Write-Host "Already configured: $normalized" }
if ($Open) { Start-Process -FilePath (Join-Path $root 'RiskPulse.pbip') }
