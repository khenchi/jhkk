@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Initialize-RiskPulse.ps1" -Open
if errorlevel 1 pause
